<footer>
	
	<div class="container">

		<div class="socmed">
			<a href="#" class="icon icon-facebook fb"></a>
			<a href="#" class="icon icon-twitter tw"></a>
			<a href="#" class="icon icon-rss rss"></a>
			<a href="#" class="icon icon-gplus gplus"></a>
		</div>

		<span class="font_museo">Lembaga Survei Kedai Kopi</span> <br>
    	Copyright &copy; 2017, All Rights Reserved - <a href="static_page.php" class="font_museo">Privacy Policy</a>
	</div>
	
</footer>