<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="initial-scale = 1.0, user-scalable = no, width=device-width, height=device-height, maximum-scale=1.0">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Kedai Kopi</title>

    <!-- Core CSS -->
    <link href="css/style.css?opiegendut" rel="stylesheet">

    <!-- Custom styles for fonts -->
    <link href="css/font.css?opiegendut" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css?opiegendut" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="js/ie8-responsive-file-warning.js?opiegendut"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js?opiegendut"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js?opiegendut"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js?opiegendut"></script>
    <![endif]-->
</head>