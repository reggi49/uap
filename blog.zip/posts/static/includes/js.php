<!-- Core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.min.js?opiegendut"></script>
<script src="js/bootstrap.min.js?opiegendut"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="js/ie10-viewport-bug-workaround.js?opiegendut"></script>
<script src="js/imgLiquid-min.js?opiegendut"></script>
<script src="js/slick.min.js?opiegendut"></script>
<script src="js/classie.js?opiegendut"></script>
<script src="js/controller.js?opiegendut"></script>